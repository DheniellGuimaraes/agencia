<?php
if (!defined('ABSPATH')) { exit; }
class RSB_Admin_Menu {
    public static function register(): void {
        add_menu_page('Resenha Sagrada','Resenha Sagrada',rsb_admin_cap(),'rsb-dashboard',[__CLASS__,'page_dashboard'],'dashicons-awards',26);
        $pages=['configuracoes'=>'Configurações','participantes'=>'Participantes','pagamentos'=>'Pagamentos','jogos'=>'Jogos Oficiais','importar-copa'=>'Importar Copa 2026','importar-paginas'=>'Importar Páginas','palpites'=>'Palpites','resultados'=>'Resultados','ranking'=>'Ranking','premiacao'=>'Premiação','relatorios'=>'Relatórios'];
        foreach($pages as $slug=>$title){ add_submenu_page('rsb-dashboard',$title,$title,rsb_admin_cap(),'rsb-'.$slug,function() use ($slug){ self::render($slug); }); }
    }
    public static function page_dashboard(): void { self::render('dashboard'); }
    public static function render(string $view): void { if(!current_user_can(rsb_admin_cap())){wp_die(esc_html__('Acesso negado.','resenha-sagrada-bolao'));} $bolao=RSB_Bolao::current(); include RSB_PATH.'admin/views/'.$view.'.php'; }
}
