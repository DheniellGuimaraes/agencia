# Resenha Sagrada — Bolão da Copa 26

Plugin WordPress para gerenciar bolão da Copa 2026 com participantes, pagamentos, jogos, palpites, resultados, pontuação, ranking e premiação.

## Instalação

1. Envie a pasta `resenha-sagrada-bolao` para `wp-content/plugins/` ou instale o ZIP pelo painel do WordPress.
2. Ative o plugin.
3. Acesse **Resenha Sagrada** no menu administrativo.
4. Configure o bolão em **Configurações**.

## Shortcodes

### Página completa do apostador

- `[resenha_sagrada_participante]` ou `[resenha_sagrada_app]`

### Blocos separados

- `[resenha_sagrada_palpites]` — jogos abertos para registrar ou editar palpites
- `[resenha_sagrada_meus_palpites]` — histórico individual de palpites e pontos
- `[resenha_sagrada_jogos]` — calendário de jogos
- `[resenha_sagrada_ranking]` — ranking geral
- `[resenha_sagrada_premiacao]` — premiação estimada
- `[resenha_sagrada_pagamento]` — status de pagamento do participante logado
- `[resenha_sagrada_regras]` — regras do bolão

## Regras implementadas

- Placar exato: pontuação configurável, padrão 3.
- Resultado correto: pontuação configurável, padrão 1.
- Erro: 0.
- Palpite bloqueado após início do jogo.
- Ranking ordenado por pontos, placares exatos, resultados corretos e total de palpites.
- Premiação com divisão por empate: soma os prêmios das posições ocupadas e divide igualmente.

## Tabelas criadas

- wp_rs_temporadas
- wp_rs_boloes
- wp_rs_participantes
- wp_rs_jogos
- wp_rs_palpites
- wp_rs_pagamentos
- wp_rs_ranking
- wp_rs_logs

## Próximas etapas recomendadas

- Importador XLSX direto da planilha enviada.
- Exportação CSV nas telas de relatório.
- Associação automática entre usuário WordPress e participante via convite/link.
- Upload de comprovante de pagamento.
- Dashboard com Chart.js.

## Copa do Mundo 2026 — carga oficial inicial

A versão 0.2.0 inclui uma rotina para importar os 104 jogos da Copa 2026.

Caminho no WordPress:

Resenha Sagrada > Importar Copa 2026

A carga importa:

- 72 jogos da fase de grupos com seleções já definidas
- 32 jogos de mata-mata com placeholders oficiais, como vencedor do Grupo A, segundo do Grupo B e vencedores de partidas anteriores
- Datas e horários convertidos para o padrão de Brasília/São Paulo
- Cidade/local de cada partida

Status usado pelo sistema:

- `agendado`: jogo liberado para palpites até o horário de início
- `aguardando_classificados`: usado no mata-mata até o administrador trocar os placeholders pelos classificados reais
- `finalizado`: usado após lançamento de resultado

Para o mata-mata funcionar corretamente, atualize os jogos conforme os classificados forem definidos e mude o status para `agendado`. Assim os apostadores conseguirão palpitar nesses jogos até o horário de início.

## Importador de páginas do WordPress

No painel do WordPress, acesse **Resenha Sagrada > Importar Páginas** e clique em **Criar/Atualizar páginas do bolão**.

A rotina cria páginas públicas com navegação entre elas e insere automaticamente os shortcodes existentes:

- `[resenha_sagrada_participante]` — área completa do apostador
- `[resenha_sagrada_app]` — alias da área completa
- `[resenha_sagrada_palpites]` — registrar e editar palpites
- `[resenha_sagrada_meus_palpites]` — histórico dos palpites
- `[resenha_sagrada_jogos]` — jogos oficiais
- `[resenha_sagrada_ranking]` — ranking público
- `[resenha_sagrada_premiacao]` — premiação
- `[resenha_sagrada_pagamento]` — status de pagamento
- `[resenha_sagrada_regras]` — regras do bolão

Páginas criadas:

- Resenha Sagrada — Área do Apostador
- Resenha Sagrada — Palpites
- Resenha Sagrada — Meus Palpites
- Resenha Sagrada — Jogos da Copa 2026
- Resenha Sagrada — Ranking
- Resenha Sagrada — Premiação
- Resenha Sagrada — Pagamento
- Resenha Sagrada — Regras

A rotina também cria o menu **Resenha Sagrada — Bolão** no WordPress com links para as páginas importadas.


## Versão 0.4.1
- Ajuste mobile: tela inicial limpa com logo centralizada e botões Criar conta/Entrar para usuários deslogados.
- Mantido fluxo normal do bolão após login/cadastro.


## Versão 2026.1

Esta versão foi marcada como **2026.1** e consolida:

- Formato Copa 2026: 48 seleções, 12 grupos, Rodada de 32, oitavas, quartas, semifinal, terceiro lugar e final.
- Fases padronizadas: `grupos`, `rodada_32`, `oitavas`, `quartas`, `semifinal`, `terceiro_lugar`, `final`.
- Ranking de grupos e prévia de classificados: 2 primeiros por grupo + 8 melhores terceiros.
- Cadastro/login público pelo próprio plugin, sem enviar o mau elemento ao wp-admin.
- Edição do nome e telefone do mau elemento, sem liberar alteração de e-mail, pagamento ou dados de terceiros.
- Bloqueio de palpites 1 hora antes da partida, validado no servidor.
- Palpite vazio não pode ser criado após o prazo.
- Logs em `wp_rs_logs` e `wp_rs_palpite_logs`, com IP, user agent, valores antigos e novos.
- Home mobile otimizada com logo, bola animada, verde/azul/amarelo e atmosfera de campeonato.


## Versão 2026.2

Esta versão mantém a base da 2026.1 e otimiza a home pública desktop/mobile para uma experiência premium estilo SaaS esportivo 2026:

- Home de visitante com logo oficial, bola, botão Criar conta e botão Entrar.
- Cadastro e login continuam internos do plugin, sem redirecionar para wp-admin/wp-login.php.
- Visual desktop full-screen com glassmorphism, gradientes verde/azul/amarelo, elementos de futebol/campeonato e bola animada.
- Mobile preservado com logo, bola e ações principais antes do fluxo normal do bolão.
- Após login/cadastro, o mau elemento segue para o dashboard completo do bolão.


## Versão 2026.5

Esta versão mantém todas as funcionalidades da 2026.1/2026.2 e corrige apenas a experiência visual e o pós-login:

- Home pública responsiva com apenas logo, bola, background glassmorphism Copa/Brasil e botões Criar conta/Entrar.
- Cadastro e login continuam internos do plugin.
- Corrigido redirecionamento pós-login/pós-cadastro para não cair em `wp-admin/admin-ajax.php` exibindo `0`.
- Ajustes responsivos gerais para cards, navegação, formulários e tabelas em mobile/tablet/desktop.


## Versão 2026.5
- Correção do redirecionamento AJAX pós-login.
- Ajuste real de responsividade mobile dos cards de confrontos para evitar corte lateral.
- Mantidas as funcionalidades da versão 2026.3.
