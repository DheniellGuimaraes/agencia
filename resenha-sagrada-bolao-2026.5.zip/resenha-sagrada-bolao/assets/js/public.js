jQuery(function($){
  function rsbPost(form, action, successFallback){
    const btn=form.find('button[type="submit"]'), original=btn.text();
    btn.prop('disabled',true).text('Aguarde...');
    $.post(RSB_PUBLIC.ajaxUrl, form.serialize()+'&action='+action+'&nonce='+RSB_PUBLIC.nonce+'&current_url='+encodeURIComponent(window.location.href), function(resp){
      if(resp.success){
        alert((resp.data && resp.data.message) ? resp.data.message : successFallback);
        if(resp.data && resp.data.redirect){ window.location.href = resp.data.redirect; }
        else { location.reload(); }
      } else {
        alert(resp.data || 'Erro ao processar.');
      }
    }).always(function(){ btn.prop('disabled',false).text(original); });
  }

  $('.rsb-bet-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_save_bet', 'Palpite salvo com sucesso.');
  });

  $('.rsb-profile-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_update_profile', 'Dados atualizados.');
  });

  function showAuth(target){
    $('.rsb-auth-card').removeClass('rsb-auth-visible');
    $(target).addClass('rsb-auth-visible');
    document.querySelector(target)?.scrollIntoView({behavior:'smooth', block:'center'});
  }

  $(document).on('click','.rsb-show-register',function(e){
    e.preventDefault();
    showAuth('#rsb-register-form');
  });

  $(document).on('click','.rsb-show-login',function(e){
    e.preventDefault();
    showAuth('#rsb-login-form');
  });

  $('.rsb-plugin-register-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_plugin_register', 'Conta criada com sucesso.');
  });

  $('.rsb-plugin-login-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_plugin_login', 'Login realizado com sucesso.');
  });
});
