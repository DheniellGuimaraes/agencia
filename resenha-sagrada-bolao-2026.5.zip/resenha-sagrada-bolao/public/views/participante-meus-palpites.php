<?php if (!defined('ABSPATH')) exit; ?>
<div class="rsb-public rsb-section"><h3>Palpites do mau elemento</h3>
<?php if(!$participant): ?><p>Faça login com um usuário vinculado ao bolão.</p><?php elseif(empty($meus_palpites)): ?><p>O mau elemento ainda não registrou palpites.</p><?php else: ?>
<table><thead><tr><th>Jogo</th><th>Palpite do mau elemento</th><th>Resultado</th><th>Pontos</th><th>Status</th></tr></thead><tbody>
<?php foreach($meus_palpites as $p): ?>
<tr><td><?php echo esc_html($p->time_mandante.' x '.$p->time_visitante); ?></td><td><?php echo esc_html($p->palpite_gols_mandante.' x '.$p->palpite_gols_visitante); ?></td><td><?php echo is_null($p->gols_mandante) ? '—' : esc_html($p->gols_mandante.' x '.$p->gols_visitante); ?></td><td><?php echo esc_html((int)$p->pontos); ?></td><td><?php echo esc_html($p->tipo_acerto ?: $p->status); ?></td></tr>
<?php endforeach; ?>
</tbody></table><?php endif; ?></div>
